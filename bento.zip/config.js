// ╔╗ ╔═╗╔╗╔╔╦╗╔═╗
// ╠╩╗║╣ ║║║ ║ ║ ║
// ╚═╝╚═╝╝╚╝ ╩ ╚═╝
// ┌─┐┌─┐┌┐┌┌─┐┬┌─┐┬ ┬┬─┐┌─┐┌┬┐┬┌─┐┌┐┌
// │  │ ││││├┤ ││ ┬│ │├┬┘├─┤ │ ││ ││││
// └─┘└─┘┘└┘└  ┴└─┘└─┘┴└─┴ ┴ ┴ ┴└─┘┘└┘

const CONFIG = {
	// ┌┐ ┌─┐┌─┐┬┌─┐┌─┐
	// ├┴┐├─┤└─┐││  └─┐
	// └─┘┴ ┴└─┘┴└─┘└─┘

	// General
	name: localStorage.getItem('name') || 'guy',
	imageBackground: localStorage.getItem('imageBackground') === 'true',
	openInNewTab: localStorage.getItem('openInNewTab') !== 'false',
	twelveHourFormat: localStorage.getItem('twelveHourFormat') === 'true',

	// Greetings
	greetingMorning: 'Good morning!',
	greetingAfternoon: 'Good afternoon,',
	greetingEvening: 'Good evening,',
	greetingNight: 'Go to Sleep!',

	// Layout
	bentoLayout: localStorage.getItem('bentoLayout') || 'bento', // 'bento', 'lists', 'buttons'

	// Weather
	weatherKey: localStorage.getItem('weatherKey') || 'InsertYourAPIKeyHere123456', // Write here your API Key
	weatherIcons: localStorage.getItem('weatherIcons') || 'OneDark', // 'Onedark', 'Nord', 'Dark', 'White'
	weatherUnit: localStorage.getItem('weatherUnit') || 'C', // 'F', 'C'
	language: 'en', // More languages in https://openweathermap.org/current#multi

	trackLocation: localStorage.getItem('trackLocation') === 'true', // If false or an error occurs, the app will use the lat/lon below
	defaultLatitude: '37.775',
	defaultLongitude: '-122.419',

	// Autochange
	autoChangeTheme: localStorage.getItem('autoChangeTheme') === 'true',

	// Autochange by OS
	changeThemeByOS: localStorage.getItem('changeThemeByOS') === 'true',

	// Autochange by hour options (24hrs format, string must be in: hh:mm)
	changeThemeByHour: true,
	hourDarkThemeActive: '18:30',
	hourDarkThemeInactive: '07:00',

	// ┌┐ ┬ ┬┌┬┐┌┬┐┌─┐┌┐┌┌─┐
	// ├┴┐│ │ │  │ │ ││││└─┐
	// └─┘└─┘ ┴  ┴ └─┘┘└┘└─┘

	firstButtonsContainer: [
		{
			id: '1',
			name: localStorage.getItem('button1Name') || 'Github',
			icon: 'github',
			link: localStorage.getItem('button1Link') || 'https://github.com/',
		},
		{
			id: '2',
			name: localStorage.getItem('button2Name') || 'Outlook',
			icon: 'mail',
			link: localStorage.getItem('button2Link') || 'https://outlook.com/',
		},
		{
			id: '3',
			name: localStorage.getItem('button3Name') || 'Notion',
			icon: 'calendar-plus',
			link: localStorage.getItem('button3Link') || 'https://www.notion.so/',
		},
		{
			id: '4',
			name: localStorage.getItem('button4Name') || 'Intranet',
			icon: 'graduation-cap',
			link: localStorage.getItem('button4Link') || 'https://intra.epitech.eu/',
		},
		{
			id: '5',
			name: localStorage.getItem('button5Name') || 'My_Epitech',
			icon: 'disc',
			link: localStorage.getItem('button5Link') || 'https://my.epitech.eu/',
		},
		{
			id: '6',
			name: localStorage.getItem('button6Name') || 'Youtube',
			icon: 'youtube',
			link: localStorage.getItem('button6Link') || 'https://youtube.com/',
		},
	],

	secondButtonsContainer: [
		{
			id: '1',
			name: 'Music',
			icon: localStorage.getItem(`icon7Name`) || 'headphones',
			link: localStorage.getItem(`icon7Link`) || 'https://open.spotify.com',
		},
		{
			id: '2',
			name: 'twitter',
			icon: localStorage.getItem(`icon8Name`) || 'twitter',
			link: localStorage.getItem(`icon8Link`) || 'https://twitter.com/',
		},
		{
			id: '3',
			name: 'bot',
			icon: localStorage.getItem(`icon9Name`) || 'bot',
			link: localStorage.getItem(`icon9Link`) || 'https://discord.com/app',
		},
		{
			id: '4',
			name: 'Amazon',
			icon: 'shopping-bag',
			link: 'https://amazon.com/',
		},
		{
			id: '5',
			name: 'Hashnode',
			icon: 'pen-tool',
			link: 'https://hashnode.com/',
		},
		{
			id: '6',
			name: 'Figma',
			icon: 'figma',
			link: 'https://figma.com/',
		},
	],

	// ┬  ┬┌─┐┌┬┐┌─┐
	// │  │└─┐ │ └─┐
	// ┴─┘┴└─┘ ┴ └─┘

	// First Links Container
	firstlistsContainer: [
		{
			icon: localStorage.getItem(`iconlist1Name`) || 'music',
			id: '1',
			links: [
				{
					name: localStorage.getItem(`iconlist1Link1Name1`) || 'New Gen Bénin 🇧🇯 ',
					link: localStorage.getItem(`iconlist1Link1`) || 'https://open.spotify.com/playlist/01IQz6djth4BPsAYKDn8e3?si=b575b0bd4bfe4846',
				},
				{
					name: localStorage.getItem(`iconlist1Link2Name2`) || 'Late Night Vibes',
					link: localStorage.getItem(`iconlist1Link2`) || 'https://open.spotify.com/playlist/2DQ2KHEaZcT4IdcaXDSaag?si=84ad3b1b9f6a40c1',
				},
				{
					name: localStorage.getItem(`iconlist1Link3Name3`) || 'Sweet Afro_vibes',
					link: localStorage.getItem(`iconlist1Link3`) || 'https://open.spotify.com/playlist/14mrd6kzGFXd1LL57oizMG?si=nyizLlzARJ-AXTqqQoscEQ',
				},
				{
					name: localStorage.getItem(`iconlist1Link4Name4`) || 'Afropiano Vibes Only !',
					link: localStorage.getItem(`iconlist1Link4`) || 'https://open.spotify.com/playlist/0aCBFNpLrqijpfgC12w0vb?si=279eaadb76594d76',
				},
			],
		},
		{
			icon: localStorage.getItem(`iconlist2Name`) || 'coffee',
			id: '2',
			links: [
				{
					name: localStorage.getItem(`iconlist2Link1Name1`) || 'Google',
					link: localStorage.getItem(`iconlist2Link1`) || 'https://www.google.com/',
				},
				{
					name: localStorage.getItem(`iconlist2Link2Name2`) || 'Moodle',
					link: localStorage.getItem(`iconlist2Link2`) || 'https://moodle.epitest.eu/login/index.php',
				},
				{
					name: localStorage.getItem(`iconlist2Link3Name3`) || 'Google Traduction',
					link: localStorage.getItem(`iconlist2Link3`) || 'https://translate.google.com',
				},
				{
					name: localStorage.getItem(`iconlist2Link4Name4`) || 'Canva',
					link: localStorage.getItem(`iconlist2Link4`) || 'https://www.canva.com/',
				},
			],
		},
	],

	// Second Links Container
	secondListsContainer: [
		{
			icon: 'binary',
			id: '1',
			links: [
				{
					name: 'Spotify',
					link: 'https://www.spotify.com',
				},
				{
					name: 'Reddit',
					link: 'https://www.reddit.com',
				},
				{
					name: 'Hashnode',
					link: 'https://www.hashnode.com',
				},
				{
					name: 'Pocket',
					link: 'https://www.pocket.com',
				},
			],
		},
		{
			icon: 'github',
			id: '2',
			links: [
				{
					name: 'Front',
					link: 'https://www.reddit.com/r/Frontend/',
				},
				{
					name: 'Rust',
					link: 'https://www.reddit.com/r/rust/',
				},
				{
					name: 'Go',
					link: 'https://www.reddit.com/r/golang/',
				},
				{
					name: 'Repos',
					link: 'https://github.com/migueravila',
				},
			],
		},
	],
};
