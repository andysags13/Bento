document.addEventListener('DOMContentLoaded', function() {
      lucide.createIcons();
  });
